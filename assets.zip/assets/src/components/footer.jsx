export default function footer(){
    return(
        <div>
            <p>This fake website example is CC0 — any part of this code may be reused in any way you wish.
                 Original example written by Chris Mills, 2016.</p>
            <p><a href="http://game-icons.net/lorc/originals/dove.html">Dove icon</a> by Lorc.</p>
        </div>
    );
}