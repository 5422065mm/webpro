import Aside from "./aside";
import Article from "./article";

export default function maincon(){
    return(
        <div>
            <Article />
            <Aside />
        </div>
    );
}